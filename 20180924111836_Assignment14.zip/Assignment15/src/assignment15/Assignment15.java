/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment15;

import java.util.Scanner;

/**
 *
 * @author 1795596
 */
public class Assignment15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TDeclare the needed variables
        int studentCount;
        int subjectCount=0;
      int i;
      int j;
        Scanner keyboard = new Scanner(System.in);
        //ask thje user number students and subjects
        System.out.println("Hello user");
         System.out.print("How many students(rows)?");
 
         studentCount = keyboard.nextInt();
         System.out.print("How many subject(column)?");
         subjectCount =keyboard.nextInt();
          // Declare the matrix  ! (2 dimensional array)
         int[][] marks = new int [studentCount][subjectCount];
         //lets loop to input the marks
         for(i= 0; i<studentCount; i++){
System.out.println("student " +(i +1));
        // marks loop
         for (j=0;j<subjectCount;j++){
             System.out.print("mark "+ (j+1) + ":");
             marks[i][j] = keyboard.nextInt();
             
         }
         }// lets loop to print this damn table
                     for(i=0;i<studentCount;i++){
                         for(j=0;j<subjectCount;j++){
                         System.out.print("|----");
                     }
                     System.out.println("|");
                     //marks 
                     for(j=0; j<subjectCount;j++){
                      System.out.print(String.format("| 3%d  ", marks[i][j]));
                         
                     }
         System.out.println("|");
         }
                      for(j=0;j<subjectCount;j++){
                         System.out.print("|----");
             }
    }
}